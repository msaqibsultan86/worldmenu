package studio.spark.worldmenu;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.world.CreateWorldScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class WorldMenuClient implements ClientModInitializer {
    private static final Identifier FOLDER_ICON = Identifier.of("worldmenu", "textures/gui/folder.png");
    private static final Identifier IMPORT_ICON = Identifier.of("worldmenu", "textures/gui/import.png");

    @Override
    public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            boolean isSelect = screen instanceof SelectWorldScreen;
            boolean isCreate = screen instanceof CreateWorldScreen;
            if (!isSelect && !isCreate) return;

            int w = 150, h = 20, y = 6;

            IconButton openFolder = new IconButton(
                    8, y, w, h, FOLDER_ICON,
                    Text.literal("Open Folder"),
                    b -> WorldActions.openSavesFolder(client));
            openFolder.setTooltip(Tooltip.of(Text.literal("Open this version's saves folder")));

            IconButton importWorld = new IconButton(
                    scaledWidth - w - 8, y, w, h, IMPORT_ICON,
                    Text.literal("Import World"),
                    b -> WorldActions.importWorld(client, screen));
            importWorld.setTooltip(Tooltip.of(Text.literal("Import a world folder into your saves")));

            Screens.getButtons(screen).add(openFolder);
            Screens.getButtons(screen).add(importWorld);
        });
    }
}
