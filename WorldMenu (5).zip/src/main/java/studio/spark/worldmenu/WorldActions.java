package studio.spark.worldmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.toast.SystemToast;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.stream.Stream;

public final class WorldActions {
    private WorldActions() {}

    private static Path savesDir(MinecraftClient client) {
        return client.getLevelStorage().getSavesDirectory();
    }

    public static void openSavesFolder(MinecraftClient client) {
        try {
            Path saves = savesDir(client);
            Files.createDirectories(saves);
            Util.getOperatingSystem().open(saves.toUri());
        } catch (Exception e) {
            toast(client, "World Menu", "Could not open the saves folder.");
        }
    }

    public static void importWorld(MinecraftClient client, Screen screen) {
        Thread t = new Thread(() -> {
            try {
                // Native FOLDER picker (LWJGL/TinyFD) — works even when AWT is headless.
                String picked = TinyFileDialogs.tinyfd_selectFolderDialog("Select a world folder to import", "");
                if (picked == null) return; // cancelled

                File worldFolder = new File(picked);
                if (!worldFolder.isDirectory()) {
                    toast(client, "Import failed", "Please select a world folder.");
                    return;
                }
                File levelDat = new File(worldFolder, "level.dat");
                if (!levelDat.exists()) {
                    toast(client, "Import failed", "That folder isn't a world (no level.dat inside).");
                    return;
                }

                Path saves = savesDir(client);
                Files.createDirectories(saves);
                Path target = uniqueTarget(saves, worldFolder.getName());
                int copied = copyDir(worldFolder.toPath(), target);

                toast(client, "World imported", "\"" + target.getFileName() + "\" added (" + copied + " files).");
                client.execute(() -> client.setScreen(new SelectWorldScreen(new TitleScreen())));
            } catch (Exception e) {
                String msg = e.getClass().getSimpleName() + (e.getMessage() != null ? ": " + e.getMessage() : "");
                toast(client, "Import failed", msg);
            }
        }, "WorldMenu-Import");
        t.setDaemon(true);
        t.start();
    }

    private static Path uniqueTarget(Path saves, String name) {
        Path target = saves.resolve(name);
        int i = 1;
        while (Files.exists(target)) { target = saves.resolve(name + "_" + i); i++; }
        return target;
    }

    private static int copyDir(Path src, Path dest) throws Exception {
        int[] count = {0};
        try (Stream<Path> stream = Files.walk(src)) {
            for (Path source : (Iterable<Path>) stream::iterator) {
                String fname = source.getFileName() != null ? source.getFileName().toString() : "";
                if (fname.equals("session.lock")) continue;
                Path rel = src.relativize(source);
                Path out = dest.resolve(rel.toString());
                try {
                    if (Files.isDirectory(source)) {
                        Files.createDirectories(out);
                    } else {
                        if (out.getParent() != null) Files.createDirectories(out.getParent());
                        Files.copy(source, out, StandardCopyOption.REPLACE_EXISTING);
                        count[0]++;
                    }
                } catch (Exception perFile) { /* skip and keep going */ }
            }
        }
        return count[0];
    }

    private static void toast(MinecraftClient client, String title, String desc) {
        client.execute(() -> {
            try {
                SystemToast.add(client.getToastManager(), SystemToast.Type.WORLD_ACCESS_FAILURE,
                        Text.literal(title), Text.literal(desc));
            } catch (Exception ignored) {}
        });
    }
}
