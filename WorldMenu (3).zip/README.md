# World Menu
Adds **Open Folder** and **Import World** buttons to the Singleplayer screen.
Fabric 1.21.4, client-side, by Spark Studios.

- 📁 Open Folder — opens this version's `saves` folder
- 📥 Import World — pick a world folder, it's validated (level.dat) and copied into saves

## Build
Push to GitHub → Actions builds with Gradle → download the **WorldMenu** artifact (jar in build/libs).
