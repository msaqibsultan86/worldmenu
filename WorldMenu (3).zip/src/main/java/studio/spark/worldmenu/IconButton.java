package studio.spark.worldmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

/** A button that draws an item icon on the left + label text, nicely aligned. */
public class IconButton extends ButtonWidget {
    private final ItemStack icon;
    private final Text label;

    public IconButton(int x, int y, int width, int height, ItemStack icon, Text label, PressAction onPress) {
        super(x, y, width, height, Text.empty(), onPress, DEFAULT_NARRATION_SUPPLIER);
        this.icon = icon;
        this.label = label;
    }

    @Override
    protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.renderWidget(ctx, mouseX, mouseY, delta);
        MinecraftClient mc = MinecraftClient.getInstance();
        int iconX = getX() + 6;
        int iconY = getY() + (getHeight() - 16) / 2;
        ctx.drawItem(icon, iconX, iconY);
        int textX = iconX + 22;
        int textY = getY() + (getHeight() - 8) / 2;
        ctx.drawText(mc.textRenderer, label, textX, textY, 0xFFFFFFFF, true);
    }
}
