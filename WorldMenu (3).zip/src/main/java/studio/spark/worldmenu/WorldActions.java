package studio.spark.worldmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.toast.SystemToast;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import javax.swing.*;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.stream.Stream;

public final class WorldActions {
    private WorldActions() {}

    private static Path savesDir(MinecraftClient client) {
        return client.getLevelStorage().getSavesDirectory();
    }

    public static void openSavesFolder(MinecraftClient client) {
        try {
            Path saves = savesDir(client);
            Files.createDirectories(saves);
            Util.getOperatingSystem().open(saves.toUri());
        } catch (Exception e) {
            toast(client, "World Menu", "Could not open the saves folder.");
        }
    }

    public static void importWorld(MinecraftClient client, Screen screen) {
        Thread t = new Thread(() -> {
            try {
                try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
                JFileChooser chooser = new JFileChooser();
                chooser.setDialogTitle("Select a world folder to import");
                chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                int result = chooser.showOpenDialog(null);
                if (result != JFileChooser.APPROVE_OPTION) return;

                File selected = chooser.getSelectedFile();
                if (selected == null || !selected.isDirectory()) {
                    toast(client, "Import failed", "Please import a valid world folder.");
                    return;
                }
                File levelDat = new File(selected, "level.dat");
                if (!levelDat.exists()) {
                    toast(client, "Import failed", "No level.dat found. Import the world FOLDER (not a .zip or a file).");
                    return;
                }

                Path saves = savesDir(client);
                Files.createDirectories(saves);
                Path target = uniqueTarget(saves, selected.getName());
                int copied = copyDir(selected.toPath(), target);

                toast(client, "World imported", "\"" + target.getFileName() + "\" added (" + copied + " files).");
                client.execute(() -> client.setScreen(new SelectWorldScreen(new TitleScreen())));
            } catch (Exception e) {
                String msg = e.getClass().getSimpleName() + (e.getMessage() != null ? ": " + e.getMessage() : "");
                toast(client, "Import failed", msg);
            }
        }, "WorldMenu-Import");
        t.setDaemon(true);
        t.start();
    }

    private static Path uniqueTarget(Path saves, String name) {
        Path target = saves.resolve(name);
        int i = 1;
        while (Files.exists(target)) { target = saves.resolve(name + "_" + i); i++; }
        return target;
    }

    /** Robust recursive copy: skips lock files, replaces existing, keeps going on per-file errors. */
    private static int copyDir(Path src, Path dest) throws Exception {
        int[] count = {0};
        try (Stream<Path> stream = Files.walk(src)) {
            for (Path source : (Iterable<Path>) stream::iterator) {
                String fname = source.getFileName() != null ? source.getFileName().toString() : "";
                if (fname.equals("session.lock")) continue;
                Path rel = src.relativize(source);
                Path out = dest.resolve(rel.toString());
                try {
                    if (Files.isDirectory(source)) {
                        Files.createDirectories(out);
                    } else {
                        if (out.getParent() != null) Files.createDirectories(out.getParent());
                        Files.copy(source, out, StandardCopyOption.REPLACE_EXISTING);
                        count[0]++;
                    }
                } catch (Exception perFile) {
                    // skip problem files, keep importing the rest
                }
            }
        }
        return count[0];
    }

    private static void toast(MinecraftClient client, String title, String desc) {
        client.execute(() -> {
            try {
                SystemToast.add(client.getToastManager(), SystemToast.Type.WORLD_ACCESS_FAILURE,
                        Text.literal(title), Text.literal(desc));
            } catch (Exception ignored) {}
        });
    }
}
