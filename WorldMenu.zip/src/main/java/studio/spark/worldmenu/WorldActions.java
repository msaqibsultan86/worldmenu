package studio.spark.worldmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.toast.SystemToast;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import javax.swing.*;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.stream.Stream;

public final class WorldActions {
    private WorldActions() {}

    private static Path savesDir(MinecraftClient client) {
        return client.getLevelStorage().getSavesDirectory();
    }

    public static void openSavesFolder(MinecraftClient client) {
        try {
            Path saves = savesDir(client);
            Files.createDirectories(saves);
            Util.getOperatingSystem().open(saves.toUri());
        } catch (Exception e) {
            toast(client, "World Menu", "Could not open the saves folder.");
        }
    }

    public static void importWorld(MinecraftClient client, Screen screen) {
        // run the file chooser off the render thread
        Thread t = new Thread(() -> {
            try {
                try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
                JFileChooser chooser = new JFileChooser();
                chooser.setDialogTitle("Select a world folder to import");
                chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                int result = chooser.showOpenDialog(null);
                if (result != JFileChooser.APPROVE_OPTION) return;

                File selected = chooser.getSelectedFile();
                if (selected == null || !selected.isDirectory()) {
                    toast(client, "Import failed", "Please import a valid world folder.");
                    return;
                }
                File levelDat = new File(selected, "level.dat");
                if (!levelDat.exists()) {
                    toast(client, "Import failed", "Please import a valid world folder (no level.dat found).");
                    return;
                }

                Path saves = savesDir(client);
                Files.createDirectories(saves);
                Path target = uniqueTarget(saves, selected.getName());
                copyDir(selected.toPath(), target);

                toast(client, "World imported", "\"" + target.getFileName() + "\" was added to your saves.");
                // refresh the world list on the main thread
                client.execute(() -> client.setScreen(new SelectWorldScreen(new TitleScreen())));
            } catch (Exception e) {
                toast(client, "Import failed", "Something went wrong while importing.");
            }
        }, "WorldMenu-Import");
        t.setDaemon(true);
        t.start();
    }

    private static Path uniqueTarget(Path saves, String name) {
        Path target = saves.resolve(name);
        int i = 1;
        while (Files.exists(target)) {
            target = saves.resolve(name + "_" + i);
            i++;
        }
        return target;
    }

    private static void copyDir(Path src, Path dest) throws Exception {
        try (Stream<Path> stream = Files.walk(src)) {
            stream.forEach(source -> {
                try {
                    Path rel = src.relativize(source);
                    Path out = dest.resolve(rel.toString());
                    if (Files.isDirectory(source)) Files.createDirectories(out);
                    else {
                        Files.createDirectories(out.getParent());
                        Files.copy(source, out);
                    }
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            });
        }
    }

    private static void toast(MinecraftClient client, String title, String desc) {
        client.execute(() -> {
            try {
                SystemToast.add(client.getToastManager(), SystemToast.Type.WORLD_ACCESS_FAILURE,
                        Text.literal(title), Text.literal(desc));
            } catch (Exception ignored) {}
        });
    }
}
