package studio.spark.worldmenu;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class WorldMenuClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!(screen instanceof SelectWorldScreen)) return;

            ButtonWidget openFolder = ButtonWidget.builder(
                    Text.literal("\uD83D\uDCC1 Open Folder"),
                    b -> WorldActions.openSavesFolder(client))
                .dimensions(8, 6, 120, 20)
                .tooltip(net.minecraft.client.gui.tooltip.Tooltip.of(Text.literal("Open this version's saves folder")))
                .build();

            ButtonWidget importWorld = ButtonWidget.builder(
                    Text.literal("\uD83D\uDCE5 Import World"),
                    b -> WorldActions.importWorld(client, screen))
                .dimensions(scaledWidth - 128, 6, 120, 20)
                .tooltip(net.minecraft.client.gui.tooltip.Tooltip.of(Text.literal("Import a world folder into your saves")))
                .build();

            Screens.getButtons(screen).add(openFolder);
            Screens.getButtons(screen).add(importWorld);
        });
    }
}
